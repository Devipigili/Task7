
# Task 7: SQL Views - Elevate Labs

## Objective
To learn how to create and use views in SQL for abstraction and reusable logic.

## Tools Used
- DB Browser for SQLite

## Files
- `task7.sql`: SQL file containing table creation, data insertion, view creation, and view query.

## View Created
- **View Name**: `high_salary_employees`
- **Definition**:
```sql
SELECT name, department, salary
FROM employees
WHERE salary > 60000;
```

## Output
The view returns employees whose salary is greater than 60000.

## Screenshot
Refer to the attached screenshot showing output of the view.

## Concepts Used
- CREATE VIEW
- SELECT with WHERE clause
- Data Abstraction
