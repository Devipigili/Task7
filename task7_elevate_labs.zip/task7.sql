
-- Create a sample "employees" table
CREATE TABLE employees (
    emp_id INTEGER PRIMARY KEY,
    name TEXT,
    department TEXT,
    salary INTEGER
);

-- Insert sample data
INSERT INTO employees (emp_id, name, department, salary) VALUES
(1, 'Alice', 'HR', 50000),
(2, 'Bob', 'IT', 70000),
(3, 'Charlie', 'Finance', 65000),
(4, 'David', 'IT', 72000),
(5, 'Eve', 'HR', 52000);

-- Create a view for high salary employees
CREATE VIEW high_salary_employees AS
SELECT name, department, salary
FROM employees
WHERE salary > 60000;

-- Use the view
SELECT * FROM high_salary_employees;
